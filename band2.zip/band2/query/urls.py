from django.conf.urls import url
from . import views


urlpatterns=[
    url(r'^$', views.index, name='index'),
    url(r'^contact/', views.contact),
    url(r'^insertdone/', views.insertalbum),
    url(r'^tableview/', views.tableview),
    url(r'^insertalbum/', views.viewForm),
    url(r'^addsong/', views.viewSong),
    url(r'^songdone/', views.songDone),
    url(r'^(?P<album_id>[0-9]+)deletesong(?P<song_id>[0-9]+)/', views.deleteSong),
    url(r'^searchalbum/', views.searchalbum),
    url(r'^searchband/', views.searchband),
    url(r'^searchconcert/', views.searchconcert)
]
