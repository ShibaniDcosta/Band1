from django.db import models

# Create your models here.


class Band(models.Model):
    Band_id = models.IntegerField()
    Band_name = models.CharField(max_length=50, blank=False)
    No_of_members = models.IntegerField()
    Office_address = models.CharField(max_length=50)

    def __str__(self):
        return self.Band_name


class MemberDetails(models.Model):
    Member_id = models.IntegerField()
    Member_name = models.CharField(max_length=50, blank=False)
    Band_id = models.ForeignKey(Band, on_delete=models.CASCADE)
    Contact = models.BigIntegerField()
    Address = models.CharField(max_length=100)
    Specialization = models.CharField(max_length=50)

    def __str__(self):
        return self.Member_name


class Albums(models.Model):
    Band_name = models.ForeignKey(Band, on_delete=models.CASCADE)
    Album_name = models.CharField(max_length=50)
    genre = models.CharField(max_length=30, default="POP")

    def __str__(self):
        return self.Album_name


class Concert(models.Model):
    Time = models.TimeField(blank=False)
    Date = models.DateField(blank=False)
    Venue = models.CharField(max_length=100, blank=False)
    Band_id = models.ForeignKey(Band, on_delete=models.CASCADE)

    def __str__(self):
        return self.Venue+" "+str(self.Date)+" "+str(self.Band_id)


class Music(models.Model):
    Album_id = models.ForeignKey(Albums, on_delete=models.CASCADE)
    Song_name = models.CharField(max_length=250, blank=False)

    def __str__(self):
        return self.Song_name
