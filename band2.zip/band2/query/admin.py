from django.contrib import admin
from .models import Band, MemberDetails, Albums, Concert, Music
# Register your models here.

admin.site.register(Band)
admin.site.register(MemberDetails)
admin.site.register(Albums)
admin.site.register(Concert)
admin.site.register(Music)
