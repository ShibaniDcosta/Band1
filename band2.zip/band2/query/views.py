from django.http import HttpResponse
from .models import Band, MemberDetails, Albums, Music, Concert
from django.shortcuts import render
from datetime import date
import time


def index(request):
    return render(request, 'query/index.html')


def home(request):
    return render(request, 'query/home.html')


def contact(request):
    return render(request, 'query/contact.html')


def tableview(request):
    b = Band.objects.all()
    a = Albums.objects.all()
    c = Concert.objects.all()
    dic = {"band": b, "album": a, "concert": c}
    return render(request, 'query/view.html', dic)


def AddAlbum(request):
    a = Albums()
    a.Album_name = request.POST["albumname"]
    a.Band_name = Band.objects.get(pk=request.POST["band"])
    a.Genre = request.POST["genre"]
    a.save()
    dic = {"album": a}
    return render(request, "query/AddSong.html", dic)


def viewForm(request):
    b = Band.objects.all()
    dic = {"band_get": b}
    return render(request, 'query/AddAlbum.html', dic)


def viewSong(request):
    album = Albums.objects.all()
    dic = {"album_get": album}
    return render(request, 'query/AddSong.html', dic)


def insertalbum(request):
    if not request.POST["albumname"]:
        b = Band.objects.all()
        dic = {"band_get": b, "albumname": True}
        return render(request, 'query/AddAlbum.html', dic)
   # elif not request.POST["genre"]:
    #    b = Band.objects.all()
     #   dic = {"band_get": b, "genrename": True}
      #  return render(request, 'query/AddAlbum.html', dic)
    else:
        a = Albums()
        a.Band_name = Band.objects.get(pk=request.POST["band"])
        a.Album_name = request.POST["albumname"]
        a.genre = request.POST["genre"]
        a.save()
        b = Band.objects.all()
        dic = {"band_get": b}
        return render(request, 'query/AddAlbum.html', dic)


def songDone(request):
    if not request.POST["songname"]:
        a = Albums.objects.all()
        dic = {"album_get": a, "songname": True}
        return render(request, 'query/AddSong.html', dic)
    else:
        s = Music()
        s.Song_name = request.POST["songname"]
        s.Album_id = Albums.objects.get(pk=request.POST["album"])
        s.save()
        a = Albums.objects.all()
        dic = {"album_get": a}
        return render(request, 'query/AddSong.html', dic)


def deleteSong(request, song_id, album_id):
    m = Music.objects.get(pk=song_id)
    m.delete()
    a = Albums.objects.get(pk=album_id)
    s = a.music_set.all()
    return render(request, 'query/SearchAlbum.html', {"album": a, "music": s})


def searchalbum(request):
    a = Albums.objects.get(pk=request.POST["dropalbum"])
    s = a.music_set.all()
    return render(request, 'query/SearchAlbum.html', {"album": a, "music": s})


def searchband(request):
    b = Band.objects.get(pk=request.POST["dropband"])
    name = b.memberdetails_set.all()
    dic = {"band1": b, "members": name}
    return render(request, 'query/SearchBand.html', dic)


def searchconcert(request):
    b = Band.objects.get(pk=request.POST["dropconcert"])
    c = b.concert_set.all()
    today = date.fromtimestamp(time.time())
    dic = {"concert": c, "band": b, "today": today}
    return render(request, 'query/SearchConcert.html', dic)




